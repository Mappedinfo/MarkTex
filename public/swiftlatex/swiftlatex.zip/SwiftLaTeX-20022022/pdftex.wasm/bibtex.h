/* tectonic/bibtex.h
   Copyright 2017 the Tectonic Project
   Licensed under the MIT License.
*/

#ifndef BIBTEX_H
#define BIBTEX_H

int bibtex_main(const char *aux_file_name);

#endif
