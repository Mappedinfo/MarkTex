//========================================================================
//
// SplashFontFileID.cc
//
// Copyright 2003-2013 Glyph & Cog, LLC
//
//========================================================================

#include <aconf.h>

#ifdef USE_GCC_PRAGMAS
#pragma implementation
#endif

#include "gmempp.h"
#include "SplashFontFileID.h"

//------------------------------------------------------------------------
// SplashFontFileID
//------------------------------------------------------------------------

SplashFontFileID::SplashFontFileID() {
}

SplashFontFileID::~SplashFontFileID() {
}
