#define ETEX_VERSION "2.6"
